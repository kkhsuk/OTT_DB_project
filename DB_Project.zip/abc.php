<?php

   $tmsg = $_POST['tmsg'];

   $tmsg2 = $_POST['tmsg2'];
   echo "1";
   $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
  	$query2 = "insert into ott_user (ID,PW) values ('$tmsg','$tmsg2')";
    $stmt2 = oci_parse($conn, $query2);
    $result = oci_execute($stmt2);

    echo $result;

    $query = "select * from "
  	$row_num = oci_fetch_all($stmt2, $row);

    echo $row_num;

    oci_close($conn);
?>
