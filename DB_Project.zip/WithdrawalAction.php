<?php

ini_set('display_errors','0');
	session_start();
	$check_id = $_SESSION['login_id'];
	$login_id = $_POST['login_id'];
	$login_pw = $_POST['login_pw'];

	$conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

	$querys = "select * from ott_user where ID='$check_id' AND PW='$login_pw' and ID = '$login_id'";


	$stmts = oci_parse($conn, $querys);
	oci_execute($stmts);
	$row_num = oci_fetch_all($stmts, $row);

	if($row_num == 1)
	{
		$query = "delete from ott_user
		where ID = '$check_id'
		and PW = '$login_pw'";

		$stmt = oci_parse($conn, $query);
		oci_execute($stmt);
		echo '<script> alert("회원정보가 삭제되었습니다");</script>';
		echo "<script>location.href='index.php';</script>";

	} else
	{
		echo '<script> alert("잘못 입력하였습니다.");</script>';
		echo "<script>location.href='Withdrawal.php';</script>";
	}
oci_close($conn);
?>
