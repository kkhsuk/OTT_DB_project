<?php
ini_set('display_errors','0');
session_start();
include('login_check');

$login_id = $_SESSION['login_id'];
$genre = $_POST['genre'];

echo $genre;
echo $login_id;

$conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
$wishquery = "update ott_user set genre = '$genre' where ID = '$login_id'";
$state = oci_parse($conn, $wishquery);
oci_execute($state);
oci_close($conn);


echo "<script>location.href='main.php';</script>";


?>
