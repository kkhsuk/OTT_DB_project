<?php


   $ID = $_POST['userID'];

    $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");


    // $query1 = "delete from mv_watchlist where ID = '$ID'";
    // $stmt1 = oci_parse($conn, $query1);
    // oci_execute($stmt1);
    //
    // $query2 = "delete from mv_wishlist where ID = '$ID'";
    // $stmt2 = oci_parse($conn, $query2);
    // oci_execute($stmt2);
    //
    // $query3 = "delete from tv_watchlist where ID = '$ID'";
    // $stmt3 = oci_parse($conn, $query3);
    // oci_execute($stmt3);
    //
    // $query4 = "delete from tv_wishlist where ID = '$ID'";
    // $stmt4 = oci_parse($conn, $query4);
    // oci_execute($stmt4);

    $query5 = "delete from ott_user where ID = '$ID'";
    $stmt5 = oci_parse($conn, $query5);
    oci_execute($stmt5);

    oci_close($conn);
?>
