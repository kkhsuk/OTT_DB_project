<?php

ini_set('display_errors','0');
session_start();
include('login_check');

?>

<!DOCTYPE html>
<html lang="ko">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>OTT Service</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

  <!-- Custom styles for this template -->
  <link href="css/agency.css" rel="stylesheet">

  <!-- <link rel="stylesheet" href="css/slider_bootstrap.min.css"> -->
  <link rel="stylesheet" href="css/slider_style.css">
  <script src="js/slider_index.js"></script>


</head>

<style>

body{background-color: #292929;}

</style>


</head>
<body class = "footer">

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="http://software.hongik.ac.kr/b_team/b_team3/Soon/main.php">OTT service</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      Menu
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav text-uppercase ml-auto">
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="http://software.hongik.ac.kr/b_team/b_team3/Soon/movie.php">Movies</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="http://software.hongik.ac.kr/b_team/b_team3/Soon/tv.php">Televisions</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="http://software.hongik.ac.kr/b_team/b_team3/Soon/wishlist.php">찜한목록</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="http://software.hongik.ac.kr/b_team/b_team3/Soon/watchlist.php">시청목록</a>
        </li>
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#contact">MY</a>
          <ul class="dropdown" style="padding-left: 0px;">
            <li><a href="http://software.hongik.ac.kr/b_team/b_team3/Soon/update.php">계정 수정</a></li>
            <li><a href="http://software.hongik.ac.kr/b_team/b_team3/Soon/Withdrawal.php">계정 삭제</a></li>
            <li><a href="http://software.hongik.ac.kr/b_team/b_team3/Soon/logout.php">로그 아웃</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<br><br><br><br>
<?php
echo "<iframe width='1000' height='600' src='".$_SESSION['url']."' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"
?>
<br><br>
<div class="checkbox">

    <button class = "btn btn-primary btn-xl text-uppercase js-scroll-trigger" style="margin : 50px" onclick="location.href='wishcheck.php'">찜하기</button>
    <button class = "btn btn-primary btn-xl text-uppercase js-scroll-trigger" style="margin : 50px" onclick="location.href='wishcancle.php'">찜취소</button>

</div>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Contact form JavaScript -->
<script src="js/jqBootstrapValidation.js"></script>
<script src="js/contact_me.js"></script>

<!-- Custom scripts for this template -->
<script src="js/agency.min.js"></script>


 </body>


</html>
