<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>
<?php

ini_set('display_errors','0');


	session_start();

	$login_id = $_POST['login_id'];
	$login_pw = $_POST['login_pw'];


	$conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
	$query = "select * from ott_user where ID='$login_id' AND PW='$login_pw'";

	$stmt = oci_parse($conn, $query);
	oci_execute($stmt);
	$row_num = oci_fetch_all($stmt, $row);

	if($row_num == 1)
	{
		echo '<script> alert("성공적으로 로그인 하였습니다.");</script>';
	 	$_SESSION['login_id']=$login_id;
		echo "<script>location.href='main.php';</script>";

	} else
	{
			echo "<script>location.href='login_check.php';</script>";
	}
	oci_close($conn);
?>

</body>
</html>
