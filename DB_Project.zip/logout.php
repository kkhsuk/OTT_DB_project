<?php
	ini_set('display_errors','0');
	session_start();
	$res = session_destroy();

if($res)
{
	echo '<script> alert("성공적으로 로그아웃 되셨습니다.");</script>';
	echo"<script>location.href='index.php';</script>";
}
else {
}

?>
