<?php

  ini_set('display_errors','0');
  session_start();
  include('login_check');

  $time =  mktime();
  $date = date("YmdHis", $time);

  $ID = $_SESSION['login_id'];
  $title = $_SESSION['title'];
  $videonum = $_SESSION['videonumber'];

  $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

  if(strpos($videonum,"m") !== false){
    $deletequery = "delete from mv_wishlist where ID = '$ID' AND VIDEO_NUM = '$videonum'";
    $dstate = oci_parse($conn, $deletequery);
    oci_execute($dstate);

    $wishquery = "insert into mv_wishlist values ('$ID','$title','$videonum',$date)";
    $istate = oci_parse($conn, $wishquery);
    oci_execute($istate);
  }

  else if(strpos($videonum,"t") !== false){
    $deletequery = "delete from tv_wishlist where ID = '$ID' AND VIDEO_NUM = '$videonum'";
    $dstate = oci_parse($conn, $deletequery);
    oci_execute($dstate);

    $wishquery = "insert into tv_wishlist values ('$ID','$title','$videonum',$date)";
    $istate = oci_parse($conn, $wishquery);
    oci_execute($istate);
  }

  oci_close($conn);

  echo "<script>location.href='video.php';</script>";

?>
