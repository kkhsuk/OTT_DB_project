<?php

ini_set('display_errors','0');
session_start();
include('login_check');


$time =  mktime();
$date = date("YmdHis", $time);

$login_id = $_SESSION['login_id'];

$videonum = $_POST['watchnumber'];
$title = $_POST['title'];
// $url = $_POST['url'];

$_SESSION['url'] = $_POST['url'];
$_SESSION['videonumber'] = $_POST['watchnumber'];
$_SESSION['title'] = $_POST['title'];



if(strpos($videonum,"m") !== false){
$conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
$watchquery = "insert into mv_watchlist values ('$login_id','$title','$videonum',$date)";
$state = oci_parse($conn, $watchquery);
oci_execute($state);
oci_close($conn);
}

else if(strpos($videonum,"t") !== false){
$conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
$watchquery = "insert into tv_watchlist values ('$login_id','$title','$videonum',$date)";
$state = oci_parse($conn, $watchquery);
oci_execute($state);
oci_close($conn);
}

echo "<script>location.href='video.php';</script>";

?>
