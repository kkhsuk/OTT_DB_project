<?php

ini_set('display_errors','0');

$new_id = $_POST[new_id];
$new_pw = $_POST[new_pw];
$name = $_POST[name];
$e_mail = $_POST[e_mail];


$conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

$querys = "select ott_user.ID from ott_user where ID ='$new_id'";
$stmts = oci_parse($conn,$querys);
oci_execute($stmts);
$row_num = oci_fetch_all($stmts, $row);

if($row_num ==1)
{
	echo'<script> alert("아이디가 이미 존재합니다.");</script>';
}

else{
	$query = "insert into ott_user (ID,PW,name,e_mail) values('$new_id', '$new_pw', '$name','$e_mail')";
	$stmt = oci_parse($conn, $query);
	oci_execute($stmt);


	echo '<script> alert("환영합니다! 회원가입이 성공적으로 되었습니다.");</script>';
}
oci_close($conn);
?>

<script>
location.href = "index.php";
</script>
