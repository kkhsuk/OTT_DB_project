<?php

   $tmsg = $_POST['tmsg'];

   $tmsg2 = $_POST['tmsg2'];

   $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
  	$query2 = "select * from ott_user where ID='$tmsg' AND PW='$tmsg2'";
    $stmt2 = oci_parse($conn, $query2);
    oci_execute($stmt2);
  	$row_num = oci_fetch_all($stmt2, $row);

    echo $row_num;

    oci_close($conn);
?>
