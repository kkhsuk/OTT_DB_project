<?php

   $videonum = $_POST['videonum'];

   $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

   if(strpos($videonum,"m") !== false){

   $query1 = "select android_URL from movie where VIDEO_NUM='$videonum'";
   $stmt1 = oci_parse($conn, $query1);
   oci_execute($stmt1);
   $row = oci_fetch_array($stmt1,OCI_BOTH);
   echo $row[0];
  }


  else if(strpos($videonum,"t") !== false){
     $query2 = "select android_URL from tv where VIDEO_NUM='$videonum'";
     $stmt2 = oci_parse($conn, $query2);
     oci_execute($stmt2);
     $row = oci_fetch_array($stmt2,OCI_BOTH);
     echo $row[0];
   }

    oci_close($conn);
?>
