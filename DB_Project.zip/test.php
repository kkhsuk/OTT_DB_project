<?php

   $tmsg = $_POST['tmsg'];


   $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

   if(strpos($videonum,"m") !== false){

   $query1 = "select android_URL from movie where VIDEO_NUM='$tmsg'";
   $stmt1 = oci_parse($conn, $query1);
   $result = oci_execute($stmt1);
   $row = oci_fetch_array($stmt1,OCI_BOTH)
   echo $row[0];
  }


  else if(strpos($videonum,"t") !== false){
     $query2 = "select android_URL from tv where VIDEO_NUM='$tmsg'";
     $stmt2 = oci_parse($conn, $query2);
     $result = oci_execute($stmt2);
     $row = oci_fetch_array($stmt1,OCI_BOTH)
     echo $row[0];
   }

    oci_close($conn);
?>
