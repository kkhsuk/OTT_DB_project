<?php

ini_set('display_errors','0');
session_start();
include('login_check');


  $ID = $_SESSION['login_id'];
  $videonum = $_SESSION['videonumber'];
  $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

  if(strpos($videonum,"m") !== false){

    $deletequery = "delete from mv_wishlist where ID = '$ID' AND VIDEO_NUM = '$videonum'";
    $stmt = oci_parse($conn, $deletequery);
    oci_execute($stmt);

  }

  else if(strpos($videonum,"t") !== false){

    $deletequery = "delete from tv_wishlist where ID = '$ID' AND VIDEO_NUM = '$videonum'";
    $stmt = oci_parse($conn, $deletequery);
    oci_execute($stmt);

  }

  oci_close($conn);

  echo "<script>location.href='video.php';</script>";

?>
