<?php

ini_set('display_errors','0');
   session_start();

   $check_id = $_SESSION['login_id'];
   $P_PW = $_POST['P_PW'];
   $P_PW1 = $_POST['P_PW1'];

   $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");

	$query = "select * from ott_user where ID='$check_id' AND PW='$P_PW'";

	$stmt = oci_parse($conn, $query);
    oci_execute($stmt);
	$row_num = oci_fetch_all($stmt, $row);

	if($row_num == 1)
	{
	$querye = "UPDATE ott_user
		  set PW ='$P_PW1'
	          where ID='$check_id' AND PW='$P_PW'";

	$stmte = oci_parse($conn, $querye);
	oci_execute($stmte);
	echo '<script> alert("성공적으로 변경되었습니다.");</script>';
	echo "<script>location.href='index.php';</script>";

	} else
	{
		echo '<script> alert("현재 비밀번호가 틀렸습니다.");</script>';
		echo "<script>location.href='update.php';</script>";
	}
	oci_close($conn);

?>
