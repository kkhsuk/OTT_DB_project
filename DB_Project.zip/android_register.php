<?php

   $ID = $_POST['inputID'];

   $PW = $_POST['inputPW'];


   $conn = oci_connect("b589006", "soon", "203.249.87.162:1521/orcl");
  	$query1 = "insert into ott_user (ID,PW) values ('$ID','$PW')";
    $stmt1 = oci_parse($conn, $query1);
    $result = oci_execute($stmt1);

     $query2 = "select * from ott_user where ID='$ID' AND PW='$PW'";
     $stmt2 = oci_parse($conn, $query2);
     $result = oci_execute($stmt2);
     $row_num = oci_fetch_all($stmt2, $row);

    echo $row_num;

    oci_close($conn);
?>
