<!DOCTYPE html>
<html lang="ko">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>OTT Service</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

  <!-- Custom styles for this template -->
  <link href="css/agency.css" rel="stylesheet">

  <!-- <link rel="stylesheet" href="css/slider_bootstrap.min.css"> -->
  <link rel="stylesheet" href="css/slider_style.css">
  <script src="js/slider_index.js"></script>


</head>
<style>
body{
background-color : #292929;
padding-top:4.2rem;
padding-bottom:4.2rem;
background:rgba(41, 41, 41, 0.2);
}
a{
 text-decoration:none !important;
 }
 h1,h2,h3{
 font-family: 'Kaushan Script', cursive;
 }
  .myform{
position: relative;
display: -ms-flexbox;
display: flex;
padding: 1rem;
-ms-flex-direction: column;
flex-direction: column;
width: 100%;
pointer-events: auto;
background-color: #fff;
background-clip: padding-box;
border: 1px solid rgba(41,41,41,0.2);
border-radius: 1.1rem;
outline: 0;
max-width: 500px;
}
 .tx-tfm{
 text-transform:uppercase;
 }
 .mybtn{
 border-radius:50px;
 }

 .login-or {
 position: relative;
 color: #aaa;
 margin-top: 10px;
 margin-bottom: 10px;
 padding-top: 10px;
 padding-bottom: 10px;
 }
 .span-or {
 display: block;
 position: absolute;
 left: 50%;
 top: -2px;
 margin-left: -25px;
 background-color: #fff;
 width: 50px;
 text-align: center;
 }
 .hr-or {
 height: 1px;
 margin-top: 0px !important;
 margin-bottom: 0px !important;
 }
 .google {
 color:#666;
 width:100%;
 height:40px;
 text-align:center;
 outline:none;
 border: 1px solid lightgrey;
 }
 
</style>

<style>

body{background-color: #292929;}

</style>


</head>
<body class = "footer">

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="http://software.hongik.ac.kr/b_team/b_team3/Soon/main.php">OTT service</a>
  </div>
</nav>

<section>
<div class="container">
          <div class="row">
  			<div class="col-md-5 mx-auto">
  			<div id="first">
  				<div class="myform form ">
  					 <div class="logo mb-3">
  						 <div class="col-md-12 text-center">
  							<h1>Login</h1>
  						 </div>
  					</div>
                     <form action="loginup.php" method="post" name="login">
                             <div class="form-group">
                                <label for="exampleInputEmail1">ID</label>
                                <input type="text" name="login_id" class="form-control" id="ID" aria-describedby="emailHelp" placeholder="Enter ID">
                             </div>
                             <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input type="password" name="login_pw" id="password"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password">
                             </div>
                             <div class="col-md-12 text-center ">
                                <button type="submit" class=" btn btn-block mybtn btn-primary tx-tfm">Login</button>
                             </div>
                             <div class="col-md-12 ">
                                <div class="login-or">
                                   <hr class="hr-or">
                                   <span class="span-or"></span>
                                </div>
                             </div>
                             <div class="form-group">
                                <p class="text-center">계정이 없으신가요? <a href="sign.php" id="signup">회원가입</a></p>
                             </div>
                          </form>
  				</div>
  			</div>
			
  		</div>
        </div>
</section>
 </body>


</html>